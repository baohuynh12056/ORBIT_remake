# Đánh giá lại ToneBank bằng 2×NVIDIA T4

Bộ này triển khai đường chạy local cho **Unsteered, CAA, K-Steer và ORBIT**,
từng backbone một. Không dùng OpenAI SDK, API key, endpoint hoặc inference trả
phí. Cần Internet cho Hugging Face/PyPI và `HF_TOKEN` đã được Meta cấp quyền với
cả hai Llama. Không có GPU local đã chạy; xem [TEST_REPORT.md](TEST_REPORT.md).

## Bắt đầu

1. Tạo Kaggle Dataset riêng, ví dụ `orbit-tonebank-code`, upload **cả hai** file
   trong [dist](dist): `orbit_kaggle_bundle.zip` và `orbit_kaggle_bundle.sha256`.
   Zip chứa toàn bộ module, source numerical vendor, config, requirements,
   tests và notebook. Kaggle có thể tự giải nén ZIP thành các thư mục; notebook mới
   tự nhận cả ZIP và thư mục đã giải nén. Không cần nén lại trên Kaggle.
   Không cần clone repo hoặc đường dẫn máy cá nhân trên Kaggle.
2. Import [00_prepare_data.ipynb](notebooks/00_prepare_data.ipynb). Chọn Settings:
   **Accelerator → GPU T4 x2**, Internet On. Trong **Add-ons → Secrets**, thêm
   `HF_TOKEN`, bật quyền notebook dùng secret. Token đọc repo phải được cấp quyền
   gated Llama trên Hugging Face trước đó; bộ notebook không tự xin license.
3. Add Input Code Dataset. Giữ `MODE="smoke"`, chọn `TARGET_MODEL_ID`, đặt
   `RUN_LABEL`. Chạy toàn bộ cells, rồi chuyển lần lượt 01 → 06 theo bảng bên dưới.
   Mỗi notebook có cell tham số độc lập; giữ giống nhau mode/model/split/profile/run.
4. Chỉ sau khi `gpu_verification.json` được tạo và kiểm tra raw judge outputs,
   chạy `pilot`, sau đó `full` với RUN_LABEL mới. Smoke/pilot không phải số liệu paper.
5. Lặp bảy notebook với từng ID sau (không tải đồng thời):
   `meta-llama/Llama-3.2-3B-Instruct`, `Qwen/Qwen2.5-7B-Instruct`,
   `meta-llama/Llama-3.1-8B-Instruct`.

Python kernel cần >=3.11 để chạy bootstrap; các stage chạy bằng **worker Python
3.12.11 riêng**, kể cả khi kernel Kaggle đang dùng 3.13. Không dùng `ensurepip`
của kernel để tạo worker. Nếu code thay đổi, build lại bằng `python3 kaggle/make_notebooks.py` rồi
`python3 kaggle/build_bundle.py`. Upload version Code Dataset mới. Không trộn
bundle/config khác fingerprint với cache cũ.

Nếu tự tìm input gặp nhiều bundle, đặt `BUNDLE_ZIP` bằng **đường dẫn thư mục chứa
trực tiếp** `orbit_kaggle/`, `configs/`, `vendor/`, `requirements/` (hoặc đường dẫn
ZIP). Tên biến được giữ để tương thích với notebook trước:

```python
BUNDLE_ZIP = "/kaggle/input/TEN-DATASET-CODE"  # thay bằng đường dẫn thật trong cây Input
```

Bundle mới chứa `bundle_files.sha256.json` để kiểm checksum từng file ngay cả khi
Kaggle đã giải nén. Bootstrap cũng nhận bundle cũ đã giải nén và thông báo giới hạn:
chỉ đối chiếu được checksum vendor/prompt có sẵn; adapter/config chưa có manifest
checksum đầy đủ. Nên cập nhật Code Dataset bằng bundle mới khi thuận tiện.

Nếu đã gặp lỗi `venv ... ensurepip ... returned non-zero exit status 1`:
import lại notebook mới trong repo, khởi động lại kernel và chạy từ cell tham số.
Notebook mới nhúng bộ cài môi trường nên vẫn dùng được Code Dataset cũ đã đính
kèm; không bắt buộc upload lại để sửa riêng lỗi này. Giữ `MODE="smoke"`.
Không cần xóa `/tmp/orbit-runtime` cũ: bộ cài dùng đường dẫn mới theo fingerprint.
Khi chuyển sang notebook 01–06 cũng dùng các file notebook mới. Internet phải bật
để lần đầu tải uv, Python và package. Lỗi tạo môi trường xảy ra trước các stage,
không phải lỗi GPU hay tải weight.

## Luồng stage và artifact

```mermaid
flowchart TD
  A[00 preflight + ToneBank snapshot/split] --> B[01 backbone POS/NEG]
  B --> C[02 Qwen filter + raw judge cache]
  C --> D[03 backbone activation CPU shards]
  D --> E[03 CPU CAA / 2 MLP / ORBIT candidates + global planes]
  E --> F[04 backbone trial generation]
  F --> G[04 Qwen coherence]
  G --> H{Search completed?}
  H -->|No: persist updated bounds| F
  H -->|Yes| I[05 baseline + 3 steered methods]
  I --> J[06 Qwen target / detailed / optional ToneJudge]
  J --> K[paired scores + question bootstrap + errors + telemetry]
```

| Notebook | Input trong RUN_ROOT | Output thêm | Worker tải model |
|---|---|---|---|
| 00_prepare_data | Code Dataset | preflight, configs, data, estimate, model_check | lần lượt judge/backbone để smoke |
| 01_generate_build_responses | data completed | build + partial + resume_test | backbone (hoặc nguồn POS/NEG Qwen được chọn rõ) |
| 02_filter_build_with_qwen | build completed | judge_cache, filter | judge |
| 03_extract_and_build_artifacts | filter completed + build | activation (mọi cặp đã sinh), artifacts/classifier từ cặp đạt lọc, native vectors | backbone để extract; CPU để build/train |
| 04_calibrate | artifacts/data | calibration states, generations, judge cache/history | backbone worker thoát → judge worker thoát, lặp |
| 05_generate_evaluation | mọi calibration state completed | evaluation responses, classifier probabilities, hook audit | backbone |
| 06_judge_and_report | evaluation completed | scoring, reports, gpu_verification | judge rồi CPU report |

Input bất biến dưới `/kaggle/input/...`; helper copy cumulative RUN_ROOT sang
`/kaggle/working/orbit_runs/RUN_LABEL/MODEL_SLUG`. Copy từ đúng **một** version
mới nhất; nếu file cùng path khác checksum, helper dừng thay vì ghi đè.
Model cache, venv và extracted code ở `/tmp`, tránh lưu weight/venv vào output.
Cell cuối mỗi notebook đóng gói checkpoint thành nhiều tar.gz với giới hạn 1 GiB
uncompressed/phần để tránh hàng chục nghìn file output. Bản unpacked được chuyển
sang `/tmp` sau khi archive đã ghi và hash xong, không xóa bản duy nhất. RUN_ROOT
lúc Save chỉ chứa index và archive parts; notebook sau tự restore. Khi có lỗi
trước cell cuối, chạy riêng cell snapshot để giữ checkpoint hiện có, rồi Quick Save
kèm output files. Không archive khi một worker khác còn ghi RUN_ROOT.
Mỗi model có RUN_ROOT riêng, classifier/vector không bao giờ dùng qua model hoặc precision.

## Save Version, Add Input và resume

File trên đĩa phiên hiện tại **chưa bền vững** nếu session bị mất. `manifest.json`
completed chỉ xác nhận nội dung local; không xác nhận Kaggle đã lưu version.

* Khi chạy tương tác xong hoặc báo time-budget checkpoint, chọn **Save Version**
  góc trên phải → **Quick Save** → mở **Advanced Settings** và bật lưu **output
  files**, nếu giao diện có lựa chọn đó. Quick Save chỉ có notebook text/cell output
  mà không có output files là chưa đủ. Chờ lưu xong, vào version viewer → **Output**,
  kiểm tra `orbit_runs/...` có checkpoint_index.json cùng checkpoint-part-*.tar.gz.
  Archive chứa manifests, JSON shards và tensor; notebook sau tự kiểm checksum và giải nén.
* Cách chạy nền: chọn **Save Version → Save & Run All (Commit)**. Kaggle chạy một
  kernel mới từ đầu; nó **không kế thừa RAM hoặc file tương tác chưa được đưa thành
  input**. Vì vậy trước khi resume phải Add Input version đã lưu và đặt
  PREVIOUS_RUN_INPUT đúng. Pipeline trả exit 75 khi budget hết; notebook đánh dấu
  CHECKPOINTED và không chạy stage phụ thuộc, để phiên có thể kết thúc có output.
* Trong notebook tiếp theo: **Add Input → Notebook Outputs** (một số giao diện ghi
  Notebook Output Files) → Your Work → chọn notebook và đúng saved version → Add.
  Mở cây input, copy đường dẫn thư mục model, ví dụ
  `/kaggle/input/orbit-01-build/orbit_runs/tonebank-smoke-v1/meta-llama--Llama-3.2-3B-Instruct`
  vào PREVIOUS_RUN_INPUT. Giữ nguyên tham số khác.
* Nếu stage chưa completed, tiếp tục **chính notebook đó**, input là checkpoint
  mới nhất của nó, không chuyển sang stage sau. Từng sample/pair đã có checksum sẽ
  được bỏ qua. Generation seed không phụ thuộc thứ tự shard hay lần resume.
* Nếu lỗi phần cứng/parse: xem manifest failed, events.jsonl và raw attempts.
  Giữ config để resume lỗi tạm thời. Judge technical_error sau đủ retries được
  cache, không lặp vô hạn; muốn thử evaluator mới hoặc tăng token budget, dùng
  judge config/run mới (không sửa tay score). Re-score final outputs không cần extract lại.

### Saved version báo Output: 0 files

Không Add Input version này vào stage sau: nó chưa có checkpoint để restore.
Log `Saved-output snapshot prepared` chỉ xác nhận file đã có trong phiên lúc
cell chạy; log vẫn có thể còn sau khi file phiên đã mất. Trường
`durable_on_kaggle: false` là giá trị cố định của hàm đóng gói, không tự cập nhật
sau khi bạn Save Version.

Notebook mới kiểm tra lại file, kích thước và SHA-256 sau đóng gói. Với checkpoint
nhỏ <=64 MiB, cell cuối còn tạo `orbit-checkpoint-<run>-<model>.zip` **ngay trong
`/kaggle/working`**, có index và archive ở gốc ZIP để dễ tìm/tải từ cây file. ZIP
này chỉ là bản sao trong phiên, không tự làm saved Output có file. Checkpoint lớn
không tạo thêm ZIP để tránh nhân đôi dung lượng; vẫn lưu các archive parts như cũ.
Không cần upload lại bundle cũ để dùng kiểm tra/export nhúng trong notebook mới.

Bấm **Edit**, chạy riêng cell sau trước khi quyết định có cần chạy lại stage:

```python
from pathlib import Path
root = Path("/kaggle/working/orbit_runs/tonebank-smoke-v1/meta-llama--Llama-3.2-3B-Instruct")
files = sorted(root.glob("checkpoint*"))
print("Checkpoint còn trong phiên:", [(p.name, p.stat().st_size) for p in files])
```

* Nếu có index và archive: giữ phiên, Save Version kèm output files, chờ lưu xong
  và mở đúng version mới để kiểm tra. Quick Save chỉ có code/log là chưa đủ.
* Nếu danh sách rỗng: phiên hiện tại không còn checkpoint đã đóng gói. Nếu còn
  RUN_ROOT chưa đóng gói, chạy cell snapshot; nếu không còn cả dữ liệu run thì
  phải chạy lại 00 (hoặc restore một checkpoint đã lưu). **Save & Run All** chạy
  lại notebook từ đầu với input đã khai báo; không lấy lại file phiên đã mất.

Nếu RUN_ROOT mất file nhưng `/tmp/orbit-unpacked-<uuid>` được in trong **log mới
nhất của chính run đó** vẫn còn, có thể đóng ZIP trực tiếp thư mục backup này.
Nó chứa dữ liệu run chưa đóng gói, nên Dataset sau khi Kaggle giải nén vẫn dùng
được với restore_run. Chỉ chọn đúng backup của run hiện tại; không tự lấy backup
gần nhất của model/run khác. Nếu cả RUN_ROOT và backup đều mất thì log text
không khôi phục được dữ liệu.

Với checkpoint nhỏ của **00**, có thể tải dự phòng khi file vẫn còn bằng cell
dưới. Cell này không chạy stage/model và không tự upload hay publish:

```python
import json, os, shutil
from IPython.display import FileLink, display
index = root / "checkpoint_index.json"
assert index.is_file(), "Không còn checkpoint trong phiên; cần chạy lại hoặc restore"
info = json.loads(index.read_text())
assert all((root / part["name"]).is_file() for part in info["archives"])
backup = shutil.make_archive("/kaggle/working/orbit-stage00-checkpoint", "zip", root_dir=root)
os.chdir("/kaggle/working")
display(FileLink(Path(backup).name))
```

Tải ZIP từ link hoặc cây file `/kaggle/working`, upload ZIP làm Kaggle Dataset
riêng, rồi Add Input Dataset đó vào notebook 01 **cùng Code Dataset**. Kaggle có
thể giải nén ZIP; đặt PREVIOUS_RUN_INPUT bằng thư mục thực tế chứa trực tiếp
`checkpoint_index.json` và archive parts. Notebook tự restore, không cần giải nén
archive `.tar.gz` bằng tay. Bản tải trên máy chưa phải Input Kaggle cho đến khi
Dataset đã upload xong và được Add Input. Không tạo ZIP bổ sung cho full run lớn
nếu chưa kiểm tra dung lượng đĩa.

Kaggle hiện mô tả output notebook tối đa 20 GB; xem
[Kaggle notebook docs](https://www.kaggle.com/docs/notebooks) cho quota giao diện/tài khoản
hiện tại. Đo trước mỗi stage bằng estimate.json và disk free, đặt budget thấp hơn
giới hạn phiên thật; không giả định full run kết thúc trong một phiên.
Full calibration có thể cần nhiều version GPU, đặc biệt với fallback PyTorch của
Qwen3.5. Pilot đo throughput mới là cơ sở ước lượng thời gian thực tế.

## Cấu hình protocol

| Profile | Question pool | Build pairs/tone | Build token cap | Calibration samples tối đa | Rounds | Eval questions | Eval token cap | Combos |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| smoke | 40 | 16 | 128 | 2 | 2 | 2 | 64 | 5 (K=1) |
| pilot | 60 | 30 | 256 | 6 | 3 | 6 | 192 | 25 |
| full | 200 | 150 | 2048 | 100 | 8 | 16 | 384 | 25 |
| launcher_reference | 200 | 150 | 2048 | 100 | 8 | 16 | 384 | 25 |

`full` mặc định **question_holdout**, 25% câu hỏi build, calibration lấy tối đa
một nửa held-out, phần còn lại lấy tối đa 16 report questions như launcher.
`launcher_reference` là full với **shared_pool**; đặt SPLIT_MODE="shared_pool"
trong notebook nếu chọn profile này. Split và mọi ID được snapshot; không tuyên
bố holdout là tái lập nguyên protocol shared_pool. Không có tùy chọn tự giảm số
câu hỏi/token/combos/precision khi OOM. Smoke ít pair có thể không qua bộ lọc ở
một model; đây là lỗi thật, phải xem dữ liệu lọc và tạo smoke config mới rõ ràng
nếu muốn tăng số pair, không tạo dữ liệu giả hoặc tự nới ngưỡng.

Những chi tiết source/paper khác biệt, chuẩn hóa coherence và định nghĩa classifier
được giải thích trong [SOURCE_MAP.md](SOURCE_MAP.md). Build mặc định được chính
backbone sinh; đặt cell parameter `POS_NEG_SOURCE="qwen_judge"` (JSON: `build.response_source`) chỉ thay generation
văn bản POS/NEG và phải chọn trước stage 01 trong config mới. Không trộn response
sources; extraction vẫn từ backbone, không từ judge. Giữ POS_NEG_SOURCE giống nhau ở mọi notebook.

## Hardware và dependency

Notebook tải native wheel **uv 0.8.22** từ PyPI và kiểm SHA-256 cố định, không
cần pip/venv/ensurepip của kernel hoặc apt/sudo. uv tải managed CPython
**3.12.11**, tạo venv trong `/tmp/orbit-runtime-py312-<fingerprint>`, rồi cài
**pip 25.2** vào worker. Không sửa dependency của kernel Kaggle. Xem
[tài liệu chính thức về managed Python](https://docs.astral.sh/uv/guides/install-python/).
Python 3.12 được cố định để giữ nguyên dependency lock, gồm NumPy 1.26.4;
không cố cài lock này vào kernel 3.13.

Pin [runtime.lock.txt](requirements/runtime.lock.txt), torch 2.6.0/torchvision
0.21.0 từ official CUDA 12.4 wheel index; GPU bitsandbytes 0.48.2. PyTorch driver
và FP16 matmul được kiểm tra trước model. CPU check dùng torch 2.6.0+cpu.
Transformers **5.20.1** được xác minh từ PyPI và kiểm tra import CPU.
`pip check` phải thành công trước khi ghi marker cài đặt completed. Mỗi run lưu
`runtime_environment.json` gồm phiên bản host/worker, lock hash, installer và
dependency chính. Cài đặt lỗi có state failed và có thể chạy lại; môi trường
CPU/GPU hoặc lock khác nhận fingerprint và đường dẫn riêng.

Qwen3.5 có hybrid Gated DeltaNet + attention, khác Qwen2.5. Loader dùng
`AutoProcessor` + `AutoModelForImageTextToText`, map về
`Qwen3_5ForConditionalGeneration` theo config revision đã pin; chat template có
`enable_thinking=False` mặc định. Không dùng `/nothink` giả lập. Tham khảo
[Qwen model card](https://huggingface.co/Qwen/Qwen3.5-9B),
[Transformers Qwen3.5 docs](https://huggingface.co/docs/transformers/model_doc/qwen3_5),
[bitsandbytes hardware](https://huggingface.co/docs/transformers/quantization/bitsandbytes).
Không cài FlashAttention, flash-linear-attention hoặc causal-conv1d bắt buộc;
chấp nhận fallback PyTorch chậm trên T4 và phải xác nhận generate trên GPU.

Mặc định **FP16** cho backbone và judge, device_map=balanced, mỗi GPU có budget
riêng = VRAM free thực − reserve 2 GiB; không cộng thành một GPU 32 GiB.
Không tự CPU/disk offload hoặc đổi model/precision nếu không fit. Preflight HEAD
config và một weight ở đúng revision, rồi model-check generate thật.

Profile `judge_nf4`: backbone FP16, judge NF4/FP16 compute. Profile
`low_memory_nf4`: backbone/judge NF4/FP16 compute. Quantization chỉ dùng sau khi
smoke riêng qua model-check và intervention audit; không coi nó là kết quả FP16.
Theo docs, T4 đáp ứng phần cứng LLM.int8/NF4, nhưng chưa xác nhận sự kết hợp
Qwen3.5/bitsandbytes trên T4 này. Toàn bộ manifest chứa precision/revision/package
versions; không dùng activation FP16 để xây artifact cho run NF4.

Generation dùng microbatch 1 để RNG từng sample ổn định qua resume. Extraction
batch mặc định 8 cặp; gặp CUDA OOM giảm 8→4→2→1 và ghi event. Batch=1 vẫn OOM
thì dừng giữ checkpoint; không giảm token budget. Classifier train CPU với state
Adam, next minibatch cursor và epoch permutation seed, đã có kiểm tra resume.

## Kích thước output và chia phiên

Stage 00 ước lượng cho cả ba models: `pairs × 2 polarities × (2 × layers + 2
feature sites) × hidden_dim × 4 bytes`. Chỉ lưu một token/site, không dump mọi
token. Ví dụ 750 pairs, 32 layers, hidden4096 khoảng **1.51 GiB** activation
float32 chưa tính container/metadata. Activation lưu float32 từ tensor compute,
không nén ngầm thành FP16. Activation stage cache **mọi cặp đã sinh**, kể cả cặp hiện bị bộ lọc loại;
vector/classifier chỉ dùng accepted pairs. Đổi bộ lọc sau này có thể dùng lại
activation của cả cặp mới được chấp nhận. Vector building đọc shard CPU theo tone; không cần LLM.

Estimate còn gồm text, raw judge prompts/attempts và calibration upper bound.
Đó là dự trù, không phải dung lượng/thời gian đo trên T4. `telemetry.json` và
event logs ghi thực tế. Chỉ lưu một model trong output mỗi job; không gộp toàn bộ
activation của ba backbone vào một output. Mỗi pair/sample là một shard atomic;
TIME_BUDGET_SECONDS chia một stage dài thành nhiều saved versions. Cell snapshot gom các shard vào archive parts; không nén
lại precision activation. Giữ đúng config
và cumulative input sẽ xử lý tiếp các shard còn pending. Không chạy hai writers
đồng thời trên cùng RUN_ROOT.

## Báo cáo và chấm lại

`reports/<fingerprint>/` có per_sample.csv, detail_combinations.csv,
summary_model_method_K.csv, errors.csv, score_distributions.csv,
threshold_sensitivity.csv, REPORT.md và telemetry.json. Gồm score từng target,
coherence, paired delta, min delta, geometric gain (0 nếu có target không tăng),
fraction of targets improving và all-target success. `steering_success` được
định nghĩa là **mọi target tăng điểm so với baseline và coherence ≥50**, không
đồng nhất với boolean ToneJudge; các cột ToneJudge lưu riêng. Rubric target và
detailed luôn báo riêng, evaluator/revision/precision có trong kết quả.

CI percentile bootstrap resample question_id; các generation repeats và tổ hợp
của cùng câu hỏi được trung bình trong cluster. N_physical_responses và
n_questions không nhân baseline theo 25 context. Thiếu/technical_error giữ score
null, báo n_error/n_valid/n_paired; không impute 0, không xóa dòng. Sensitivity
coherence 40/50/60/70 chỉ mô tả test score distribution; không dùng để chọn ngưỡng.

Muốn chỉ chấm lại, restore RUN_ROOT hoàn thành 05, tạo config **mới** từ config
đã lưu và sửa `judge`/`report` (ví dụ thinking, max_new_tokens, rubric_version,
judge_types), giữ model/data/generation. Chạy trong cell sau bootstrap:

```python
rescore = json.loads(CONFIG_PATH.read_text())
rescore["judge"]["max_new_tokens"] = 1536
rescore["judge"]["rubric_version"] = "source-v1-rescore-1536"
rescore_path = RUN_ROOT / "rescore_config.json"
rescore_path.write_text(json.dumps(rescore, indent=2))
run_stage(PYTHON, rescore_path, RUN_ROOT, "score", TIME_BUDGET_SECONDS)
```

Score chỉ đọc saved evaluation, không kiểm tra lại calibration bằng evaluator
mới và không yêu cầu lại activation. Đừng chạy `verify` toàn pipeline với config
re-score khác; nó xác minh protocol calibration ban đầu. Đổi rubric text thực sự
phải sửa prompt adapter, tăng rubric_version, build bundle mới; ghi khác biệt.

Nếu muốn thay **rubric bộ lọc build** (kéo theo train/calibration mới), fork run
sang thư mục mới chỉ sao chép data/build/activation, không đổi model/precision/split:

```python
from orbit_kaggle.session import fork_build_judge_run
new_config = json.loads(CONFIG_PATH.read_text())
new_config["judge"]["rubric_version"] = "build-filter-v2"
new_config["build"]["filter_judge"] = "detailed"
new_root = Path("/kaggle/working/orbit_runs/build-filter-v2")
fork_build_judge_run(RUN_ROOT, new_root, new_config)  # RUN_ROOT đã unpacked
new_path = new_root / "resolved_config.json"
for name in ["filter", "artifacts", "calibrate", "evaluate", "score"]:
    run_stage(PYTHON, new_path, new_root, name, TIME_BUDGET_SECONDS)
```

Không chạy lại extract: activation cache gồm cả các cặp trước đó bị loại. Nếu một
stage báo checkpoint thì dừng vòng `for`, snapshot/save và tiếp tục stage đó trước.
Helper chỉ chép artifact bất biến; không giữ classifier/calibration cũ rồi coi đó
là kết quả dùng bộ lọc mới. POS/NEG generation provenance gốc vẫn được giữ nguyên.

Gộp đủ ba run có cùng split/evaluator/precision, sau khi restore mỗi RUN_ROOT:

```python
from orbit_kaggle.report import combine_reports
combine_reports(["/kaggle/working/run-llama3b", "/kaggle/working/run-qwen7b",
                 "/kaggle/working/run-llama8b"], "/kaggle/working/all_models_report")
```

Các path trong ví dụ gộp phải trỏ tới thư mục model chứa latest_report.json;
helper dừng nếu thiếu một model hoặc evaluator/split/precision khác.

## Kiểm chứng trước full

Chạy CPU suite: `PYTHONPATH=kaggle /tmp/orbit-kaggle-cpu/bin/python -m unittest
discover -s kaggle/tests -v` sau khi tạo venv/cài dependency CPU. Không cần GPU,
OpenAI SDK hoặc API key. Notebook schema/syntax, corruption/resume, JSON parser,
real source hooks trên tensor nhỏ, tiny random Llama/Qwen feature parity,
classifier optimizer resume và report fixture được kiểm tra. Fixtures unit test
không được đưa vào pipeline ToneBank hay báo cáo thực nghiệm.

Trên Kaggle phải chạy đủ smoke 00–06: đúng GPU/VRAM; load/generate judge thật;
hook/module/token audit; phương pháp đổi activation; hook cleanup; intentional
resume; calibration dùng cache keys từ judge thật; parse rate/truncation; nhãn
method. Chưa có các kiểm tra này trên T4 thì chưa có tuyên bố chạy thành công T4.
